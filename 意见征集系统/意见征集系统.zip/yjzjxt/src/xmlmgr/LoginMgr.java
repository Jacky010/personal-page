/*    */ package xmlmgr;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.net.URL;
/*    */ import java.security.CodeSource;
/*    */ import java.security.ProtectionDomain;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ public class LoginMgr
/*    */ {
/*  7 */   private String xmlPath = "";
/*    */ 
/*    */   public LoginMgr() {
/* 10 */     this.xmlPath = 
/* 11 */       getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
/* 12 */     this.xmlPath = (this.xmlPath.substring(1, this.xmlPath.indexOf("WEB-INF/classes")) + "data/admin.xml");
/*    */   }
/*    */ 
/*    */   public boolean isAdmin(String adminName, String adminPass) {
/* 16 */     boolean result = false;
/*    */     try {
/* 18 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 19 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 20 */       Document doc = builder.parse(this.xmlPath);
/* 21 */       doc.normalize();
/* 22 */       NodeList admins = doc.getElementsByTagName("admin");
/* 23 */       for (int i = 0; i < admins.getLength(); i++) {
/* 24 */         Element admin = (Element)admins.item(i);
/* 25 */         String name = admin.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
/* 26 */         String password = admin.getElementsByTagName("password").item(0).getFirstChild().getNodeValue();
/* 27 */         if ((name.equals(adminName)) && (password.equals(adminPass))) {
/* 28 */           result = true;
/* 29 */           break;
/*    */         }
/* 31 */         System.out.print("adminName: ");
/* 32 */         System.out.println(admin.getElementsByTagName("name").item(0).getFirstChild().getNodeValue());
/* 33 */         System.out.print("adminPass: ");
/* 34 */         System.out.println(admin.getElementsByTagName("password").item(0).getFirstChild().getNodeValue());
/* 35 */         System.out.println();
/*    */       }
/*    */     } catch (Exception e) {
/* 38 */       e.printStackTrace();
/*    */     }
/* 40 */     return result;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     xmlmgr.LoginMgr
 * JD-Core Version:    0.6.1
 */