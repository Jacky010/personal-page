// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoginMgr.java

package xmlmgr;

import java.io.PrintStream;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class LoginMgr
{

    public LoginMgr()
    {
        xmlPath = "";
        xmlPath = getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
        xmlPath = (new StringBuilder(String.valueOf(xmlPath.substring(1, xmlPath.indexOf("WEB-INF/classes"))))).append("data/admin.xml").toString();
    }

    public boolean isAdmin(String adminName, String adminPass)
    {
        boolean result = false;
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlPath);
            doc.normalize();
            NodeList admins = doc.getElementsByTagName("admin");
            for(int i = 0; i < admins.getLength(); i++)
            {
                Element admin = (Element)admins.item(i);
                String name = admin.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
                String password = admin.getElementsByTagName("password").item(0).getFirstChild().getNodeValue();
                if(name.equals(adminName) && password.equals(adminPass))
                {
                    result = true;
                    break;
                }
                System.out.print("adminName: ");
                System.out.println(admin.getElementsByTagName("name").item(0).getFirstChild().getNodeValue());
                System.out.print("adminPass: ");
                System.out.println(admin.getElementsByTagName("password").item(0).getFirstChild().getNodeValue());
                System.out.println();
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return result;
    }

    private String xmlPath;
}
