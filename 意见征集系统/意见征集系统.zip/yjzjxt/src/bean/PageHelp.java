/*     */ package bean;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public class PageHelp
/*     */ {
/*     */   private static int currentpage;
/*     */   private static int nextpage;
/*     */   private static int priviouspage;
/*     */   private static int pagecount;
/*     */   private static int recordcount;
/*     */   private static int pagesize;
/*     */   private String sqlstr;
/*     */   private List objectlist;
/*  12 */   private String pagebar = "";
/*     */ 
/*     */   public int getCurrentpage()
/*     */   {
/*  19 */     return currentpage;
/*     */   }
/*     */ 
/*     */   public void setCurrentpage(int currentpage) {
/*  23 */     currentpage = currentpage;
/*     */   }
/*     */ 
/*     */   public int getNextpage() {
/*  27 */     if (pagecount > currentpage)
/*  28 */       nextpage = currentpage + 1;
/*     */     else {
/*  30 */       nextpage = currentpage;
/*     */     }
/*  32 */     return nextpage;
/*     */   }
/*     */ 
/*     */   public void setNextpage(int nextpage) {
/*  36 */     nextpage = nextpage;
/*     */   }
/*     */ 
/*     */   public int getPriviouspage() {
/*  40 */     if (currentpage > 1)
/*  41 */       priviouspage = currentpage - 1;
/*     */     else {
/*  43 */       priviouspage = currentpage;
/*     */     }
/*  45 */     return priviouspage;
/*     */   }
/*     */ 
/*     */   public void setPriviouspage(int priviouspage) {
/*  49 */     priviouspage = priviouspage;
/*     */   }
/*     */ 
/*     */   public int getPagecount() {
/*  53 */     if (recordcount % pagesize == 0)
/*  54 */       pagecount = recordcount / pagesize;
/*     */     else {
/*  56 */       pagecount = recordcount / pagesize + 1;
/*     */     }
/*     */ 
/*  59 */     return pagecount;
/*     */   }
/*     */ 
/*     */   public void setPagecount(int pagecount) {
/*  63 */     pagecount = pagecount;
/*     */   }
/*     */ 
/*     */   public int getRecordcount() {
/*  67 */     return recordcount;
/*     */   }
/*     */ 
/*     */   public void setRecordcount(int recordcount) {
/*  71 */     recordcount = recordcount;
/*     */   }
/*     */ 
/*     */   public int getPagesize() {
/*  75 */     return pagesize;
/*     */   }
/*     */ 
/*     */   public void setPagesize(int pagesize) {
/*  79 */     pagesize = pagesize;
/*     */   }
/*     */ 
/*     */   public String getSqlstr() {
/*  83 */     return this.sqlstr;
/*     */   }
/*     */ 
/*     */   public void setSqlstr(String sqlstr) {
/*  87 */     this.sqlstr = sqlstr;
/*     */   }
/*     */ 
/*     */   public List getObjectlist() {
/*  91 */     return this.objectlist;
/*     */   }
/*     */ 
/*     */   public void setObjectlist(List objectlist) {
/*  95 */     this.objectlist = objectlist;
/*     */   }
/*     */ 
/*     */   public String getPagebar() {
/*  99 */     return this.pagebar;
/*     */   }
/*     */ 
/*     */   public void setPagebar(String url) {
/* 103 */     String strResult = "";
/*     */ 
/* 105 */     if (currentpage <= 1) {
/* 106 */       strResult = strResult + strResult + "[首 页] [上 页] ";
/*     */     } else {
/* 108 */       strResult = strResult + "<a href=" + url + 
/* 109 */         "&currentPage=1>[首 页]</a> ";
/* 110 */       strResult = strResult + "<a href=" + url + "&currentPage=" + (
/* 111 */         currentpage - 1) + 
/* 112 */         ">[上 页]<a>";
/*     */     }
/* 114 */     if (currentpage >= pagecount) {
/* 115 */       strResult = strResult + "[下 页] [尾 页]";
/*     */     } else {
/* 117 */       strResult = strResult + "<a href=" + url + "&currentPage=" + (
/* 118 */         currentpage + 1) + 
/* 119 */         ">[下 页]<a>";
/* 120 */       strResult = strResult + "<a href=" + url + "&currentPage=" + 
/* 121 */         pagecount + "> [尾 页]<a> ";
/*     */     }
/* 123 */     String strSelect = "<form method='post' id='f1' name='f1'>\n<select name='page' onchange='return selPage();'>\n";
/*     */ 
/* 125 */     for (int i = 1; i <= pagecount; i++) {
/* 126 */       if (currentpage == i)
/* 127 */         strSelect = strSelect + "<option value='" + i + "' selected=\"selected\">第" + i + "页</option>\n";
/*     */       else
/* 129 */         strSelect = strSelect + "<option value='" + i + "'>第" + i + "页</option>";
/*     */     }
/* 131 */     strSelect = strSelect + "\n</select>\n</form>\n<script type='text/javascript'>function selPage(){document.f1.action = '" + 
/* 132 */       url + "&currentPage='+document.f1.page.value; document.f1.submit(); return true;}</script>";
/* 133 */     strResult = "第" + currentpage + "/" + pagecount + "页,每页" + pagesize + "条  " + strResult + "   " + strSelect;
/* 134 */     if (pagecount > 1)
/* 135 */       this.pagebar = strResult;
/* 136 */     if (recordcount < 1)
/* 137 */       this.pagebar = "暂无留言";
/*     */   }
/*     */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     bean.PageHelp
 * JD-Core Version:    0.6.1
 */