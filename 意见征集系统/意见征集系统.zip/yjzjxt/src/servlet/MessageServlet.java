package servlet;

import bean.Message;
import bean.PageHelp;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import xmlmgr.MessageMgr;

public class MessageServlet extends HttpServlet
{
  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    doPost(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    request.setCharacterEncoding("UTF-8");
    response.setCharacterEncoding("UTF-8");

    String action = request.getParameter("action");
    System.out.println("action messageServlet:" + action);

    if (action.equals("list")) {
      MessageMgr messdb = new MessageMgr();
      PageHelp messageList = new PageHelp();
      messageList = messdb.getMessages(5, Integer.parseInt(request.getParameter("currentPage")));

      request.setAttribute("messageList", messageList);
      request.setAttribute("currentPage", request.getParameter("currentPage"));
      request.getRequestDispatcher("/gbook.jsp").forward(request, response);
    } else if (action.equals("add")) {
      String name = request.getParameter("name");
      String email = request.getParameter("email");
      String sex = request.getParameter("sex");
      String content = request.getParameter("content");

      Date now = new Date();
      SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

      String id = String.valueOf(now.getTime());
      String gbdate = formatter.format(now);

      Message ms = new Message();

      ms.setId(id);
      ms.setName(name);
      ms.setSex(sex);
      ms.setEmail(email);
      ms.setContent(content);
      ms.setGbdate(gbdate);
      ms.setRecontent("��δ�ظ�");
      ms.setRedate("0000-00-00 00��00��00");

      MessageMgr mm = new MessageMgr();
      if(mm.addMessage(ms)!=null)
      {
      request.setAttribute("toptips", "�������Գɹ�");
      request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
      }
    } else if (action.equals("del")) {
      String id = request.getParameter("id");
      MessageMgr mm = new MessageMgr();

      mm.delMessage(id);
      request.setAttribute("toptips", "ɾ�����Գɹ�");
      request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
    } else if (action.equals("reply")) {
      String id = request.getParameter("id");
      String recontent = request.getParameter("recontent");

      MessageMgr mm = new MessageMgr();
      mm.updateMessage(id, recontent);

      request.setAttribute("toptips", "�ظ����Գɹ�");
      request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
    }
  }
}