// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MessageMgr.java

package xmlmgr;

import bean.Message;
import bean.PageHelp;
import java.io.File;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

public class MessageMgr
{

    public MessageMgr()
    {
        xmlPath = "";
        xmlPath = getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
        xmlPath = (new StringBuilder(String.valueOf(xmlPath.substring(1, xmlPath.indexOf("WEB-INF/classes"))))).append("data/gbook.xml").toString();
    }

    public PageHelp getMessages(int pageSize, int currentPage)
    {
        int listSize = 0;
        List showlist = new ArrayList();
        PageHelp pageHelp = new PageHelp();
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlPath);
            doc.normalize();
            NodeList messages = doc.getElementsByTagName("message");
            listSize = messages.getLength();
            for(int i = listSize - 1 - (currentPage - 1) * pageSize; i >= 0 && i > listSize - 1 - currentPage * pageSize; i--)
            {
                Element message = (Element)messages.item(i);
                Message mess = new Message();
                mess.setId(message.getElementsByTagName("id").item(0).getFirstChild().getNodeValue());
                mess.setPosition(String.valueOf(i + 1));
                mess.setName(message.getElementsByTagName("name").item(0).getFirstChild().getNodeValue());
                mess.setSex(message.getElementsByTagName("sex").item(0).getFirstChild().getNodeValue());
                mess.setEmail(message.getElementsByTagName("email").item(0).getFirstChild().getNodeValue());
                mess.setContent(message.getElementsByTagName("content").item(0).getFirstChild().getNodeValue());
                mess.setGbdate(message.getElementsByTagName("gbdate").item(0).getFirstChild().getNodeValue());
                if(message.getElementsByTagName("recontent").item(0).getFirstChild().getNodeValue().equals("\u6682\u672A\u56DE\u590D"))
                    mess.setRecontent("");
                else
                    mess.setRecontent(message.getElementsByTagName("recontent").item(0).getFirstChild().getNodeValue());
                mess.setRedate(message.getElementsByTagName("redate").item(0).getFirstChild().getNodeValue());
                showlist.add(mess);
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        pageHelp.setCurrentpage(currentPage);
        pageHelp.setPagesize(pageSize);
        pageHelp.setRecordcount(listSize);
        pageHelp.getPagecount();
        pageHelp.setPagebar("messageServlet?action=list");
        pageHelp.setObjectlist(showlist);
        return pageHelp;
    }

    public int addMessage(Message ms)
    {
        int addresult = 0;
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlPath);
            doc.normalize();
            Element message = doc.createElement("message");
            Element id = doc.createElement("id");
            org.w3c.dom.Text textId = doc.createTextNode(ms.getId());
            id.appendChild(textId);
            message.appendChild(id);
            Element name = doc.createElement("name");
            org.w3c.dom.Text textName = doc.createTextNode(ms.getName());
            name.appendChild(textName);
            message.appendChild(name);
            Element sex = doc.createElement("sex");
            org.w3c.dom.Text textSex = doc.createTextNode(ms.getSex());
            sex.appendChild(textSex);
            message.appendChild(sex);
            Element email = doc.createElement("email");
            org.w3c.dom.Text textEmail = doc.createTextNode(ms.getEmail());
            email.appendChild(textEmail);
            message.appendChild(email);
            Element content = doc.createElement("content");
            org.w3c.dom.Text textContent = doc.createTextNode(ms.getContent());
            content.appendChild(textContent);
            message.appendChild(content);
            Element gbdate = doc.createElement("gbdate");
            org.w3c.dom.Text textGbdate = doc.createTextNode(ms.getGbdate());
            gbdate.appendChild(textGbdate);
            message.appendChild(gbdate);
            Element recontent = doc.createElement("recontent");
            org.w3c.dom.Text textRecontent = doc.createTextNode(ms.getRecontent());
            recontent.appendChild(textRecontent);
            message.appendChild(recontent);
            Element redate = doc.createElement("redate");
            org.w3c.dom.Text textRedate = doc.createTextNode(ms.getRedate());
            redate.appendChild(textRedate);
            message.appendChild(redate);
            doc.getDocumentElement().appendChild(message);
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(xmlPath));
            transformer.transform(source, result);
            addresult = 1;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return addresult;
    }

    public int delMessage(String id)
    {
        int delResult = 0;
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlPath);
            doc.normalize();
            NodeList list = doc.getElementsByTagName("message");
            for(int i = 0; i < list.getLength(); i++)
            {
                Element el = (Element)list.item(i);
                if(!el.getElementsByTagName("id").item(0).getFirstChild().getNodeValue().equals(id))
                    continue;
                Node del = el;
                el.getParentNode().removeChild(del);
                break;
            }

            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(xmlPath));
            transformer.transform(source, result);
            delResult = 1;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return delResult;
    }

    public int updateMessage(String id, String recontent)
    {
        int updateResult = 0;
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlPath);
            doc.normalize();
            NodeList list = doc.getElementsByTagName("message");
            for(int i = 0; i < list.getLength(); i++)
            {
                Element el = (Element)list.item(i);
                if(!el.getElementsByTagName("id").item(0).getFirstChild().getNodeValue().equals(id))
                    continue;
                Date now = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String redate = formatter.format(now);
                el.getElementsByTagName("recontent").item(0).getFirstChild().setNodeValue(recontent);
                el.getElementsByTagName("redate").item(0).getFirstChild().setNodeValue(redate);
                updateResult = 1;
                break;
            }

            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(xmlPath));
            transformer.transform(source, result);
            updateResult = 1;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return updateResult;
    }

    private String xmlPath;
}
