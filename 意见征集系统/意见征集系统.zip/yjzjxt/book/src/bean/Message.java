// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Message.java

package bean;


public class Message
{

    public Message()
    {
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getPosition()
    {
        return position;
    }

    public void setPosition(String position)
    {
        this.position = position;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getSex()
    {
        return sex;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getContent()
    {
        return Content;
    }

    public void setContent(String content)
    {
        Content = content;
    }

    public String getGbdate()
    {
        return gbdate;
    }

    public void setGbdate(String gbdate)
    {
        this.gbdate = gbdate;
    }

    public String getRedate()
    {
        return redate;
    }

    public void setRedate(String redate)
    {
        this.redate = redate;
    }

    public String getRecontent()
    {
        return recontent;
    }

    public void setRecontent(String recontent)
    {
        this.recontent = recontent;
    }

    private String id;
    private String position;
    private String name;
    private String sex;
    private String email;
    private String Content;
    private String gbdate;
    private String redate;
    private String recontent;
}
