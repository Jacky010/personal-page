// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MessageServlet.java

package servlet;

import bean.Message;
import bean.PageHelp;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import xmlmgr.MessageMgr;

public class MessageServlet extends HttpServlet
{

    public MessageServlet()
    {
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        System.out.println((new StringBuilder("action messageServlet:")).append(action).toString());
        if(action.equals("list"))
        {
            MessageMgr messdb = new MessageMgr();
            PageHelp messageList = new PageHelp();
            messageList = messdb.getMessages(5, Integer.parseInt(request.getParameter("currentPage")));
            request.setAttribute("messageList", messageList);
            request.setAttribute("currentPage", request.getParameter("currentPage"));
            request.getRequestDispatcher("/gbook.jsp").forward(request, response);
        } else
        if(action.equals("add"))
        {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String sex = request.getParameter("sex");
            String content = request.getParameter("content");
            Date now = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String id = String.valueOf(now.getTime());
            String gbdate = formatter.format(now);
            Message ms = new Message();
            ms.setId(id);
            ms.setName(name);
            ms.setSex(sex);
            ms.setEmail(email);
            ms.setContent(content);
            ms.setGbdate(gbdate);
            ms.setRecontent("\u6682\u672A\u56DE\u590D");
            ms.setRedate("0000-00-00 00\uFF1A00\uFF1A00");
            MessageMgr mm = new MessageMgr();
            mm.addMessage(ms);
            request.setAttribute("toptips", "\u6DFB\u52A0\u7559\u8A00\u6210\u529F");
            request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
        } else
        if(action.equals("del"))
        {
            String id = request.getParameter("id");
            MessageMgr mm = new MessageMgr();
            mm.delMessage(id);
            request.setAttribute("toptips", "\u5220\u9664\u7559\u8A00\u6210\u529F");
            request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
        } else
        if(action.equals("reply"))
        {
            String id = request.getParameter("id");
            String recontent = request.getParameter("recontent");
            MessageMgr mm = new MessageMgr();
            mm.updateMessage(id, recontent);
            request.setAttribute("toptips", "\u56DE\u590D\u7559\u8A00\u6210\u529F");
            request.getRequestDispatcher("dispatcher.jsp").forward(request, response);
        }
    }
}
