/*    */ package yujie;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import org.jdom.Document;
/*    */ import org.jdom.Element;
/*    */ import org.jdom.input.SAXBuilder;
/*    */ import org.jdom.output.XMLOutputter;
/*    */ 
/*    */ public class EditPassword
/*    */ {
/*    */   public int editPass(String XMLpath, String user, String pass, String newpass, String type)
/*    */   {
/* 14 */     int intCount = 0;
/*    */     try
/*    */     {
/* 18 */       SAXBuilder sb = new SAXBuilder();
/*    */ 
/* 22 */       Document doc = sb.build(new FileInputStream(XMLpath));
/*    */ 
/* 24 */       Element root = doc.getRootElement();
/*    */ 
/* 26 */       List stu = root.getChildren();
/*    */ 
/* 28 */       for (int i = 0; i < stu.size(); i++)
/*    */       {
/* 30 */         Element xs = (Element)stu.get(i);
/*    */ 
/* 33 */         if ((xs.getChildText("ID").equals(user)) && (xs.getChildText("PassWord").equals(pass)) && (xs.getChildText("Type").equals(type)))
/*    */         {
/* 35 */           Element pw = xs.getChild("PassWord");
/* 36 */           pw.setText(newpass);
/*    */ 
/* 38 */           XMLOutputter outter = new XMLOutputter();
/* 39 */           outter.output(doc, new FileOutputStream(XMLpath));
/*    */ 
/* 41 */           return 1;
/*    */         }
/*    */ 
/* 45 */         intCount = -1;
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 51 */       intCount = -2;
/* 52 */       System.err.println(e.getMessage());
/* 53 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 56 */     return intCount;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     yujie.EditPassword
 * JD-Core Version:    0.6.1
 */