package yujie;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.List;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

public class TestUser
{
  public int getUser(String XMLpath, String user, String pass, String type)
  {
    int intCount = 0;
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();
      List stu = root.getChildren();

      for (int i = 0; i < stu.size(); i++)
      {
        Element xs = (Element)stu.get(i);
        if ((xs.getChildText("ID").equals(user)) && (xs.getChildText("PassWord").equals(pass)) && (xs.getChildText("Type").equals(type)))
        {
          return 1;
        }

        intCount = -1;
      }
    }
    catch (Exception e) {
      intCount = -2;
      System.err.println(e.getMessage());
      e.printStackTrace();
    }
    return intCount;
  }

  public String getName(String XMLpath, String userID)
  {
    String UserName = "";
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();
      List stu = root.getChildren();

      for (int i = 0; i < stu.size(); i++)
      {
        Element xs = (Element)stu.get(i);

        if (xs.getChildText("ID").equals(userID))
        {
          return xs.getChildText("����");
        }

        UserName = "û�ҵ����û�ID";
      }
    }
    catch (Exception e) {
      UserName = "�û�ID�����д���";
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return UserName;
  }

  public String getBumen(String XMLpath, String userID)
  {
    String Classes = "";
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();
      List stu = root.getChildren();

      for (int i = 0; i < stu.size(); i++)
      {
        Element xs = (Element)stu.get(i);

        if (xs.getChildText("ID").equals(userID))
        {
          return xs.getChildText("����");
        }

        Classes = "û�ҵ����û�ID";
      }
    }
    catch (Exception e) {
      Classes = "�û�ID�����д���";
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return Classes;
  }

  public String getGonghao(String XMLpath, String userID)
  {
    String Classes = "";
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();
      List stu = root.getChildren();

      for (int i = 0; i < stu.size(); i++)
      {
        Element xs = (Element)stu.get(i);

        if (xs.getChildText("ID").equals(userID))
        {
          return xs.getChildText("����");
        }

        Classes = "û�ҵ����û�ID";
      }
    }
    catch (Exception e) {
      Classes = "�û�ID�����д���";
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return Classes;
  }

  public String getYes(String XMLpath, String Stu_id, String pc)
  {
    String test = "";
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();

      List lista = XPath.selectNodes(root, "/�û�����б�/�û�[����=" + Stu_id + "]");
      
      for (int i = 0; i < lista.size(); i++) {
        Element xs = (Element)lista.get(i);
        if ((xs.getChildText("����").equals(Stu_id)) && (xs.getChildText("�������").equals(pc)))
        {
          return "yes";
        }
      }
    }
    catch (Exception e) {
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return test;
  }
//ȷ��ÿ������Ա�������������Ψһ
  public String getZypcok(String xmlpath, String tea_no,  String zypc)
  {
    String ok = "";
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(xmlpath));
      Element root = doc.getRootElement();

      List list = XPath.selectNodes(root, "/�����б�/����[����Ա[@���='" + tea_no + "'" + "]]");
      for (int i = 0; i < list.size(); i++) {
        Element xs = (Element)list.get(i);
        if (xs.getChildText("�������").equals(zypc))
        {
          return "yes";
        }
      }
    }
    catch (Exception e)
    {
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return ok;
  }

//ȷ����ͨ�û����û���Ψһ
  public String getUser(String xmlpath, String tea_no)
  {
    String ok = "";
    int total = 0;
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(xmlpath));
      Element root = doc.getRootElement();  //�õ���Ԫ��  
      List stu = root.getChildren();
      for (int i = 0; i < stu.size(); i++)
      {
			Element xs = (Element)stu.get(i);
			if (xs.getChildText("ID").equals(tea_no))
				{total++;}
      }
        if (total>0)
        {
          return "yes";
        }
    }
    catch (Exception e)
    {
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return ok;
  }  
  
  public int getTotal(String XMLpath, String zy, String nj)
  {
    int total = 0;
    try {
      SAXBuilder sb = new SAXBuilder();

      Document doc = sb.build(new FileInputStream(XMLpath));
      Element root = doc.getRootElement();
      List lista = XPath.selectNodes(root, "/ѧ����Ϣ/ѧ��[רҵ='" + zy + "'" + " and �꼶='" + nj + "']");
      total = lista.size();
    }
    catch (Exception e) {
      total = 0;
      System.err.println(e.getMessage());
      e.printStackTrace();
    }

    return total;
  }
}