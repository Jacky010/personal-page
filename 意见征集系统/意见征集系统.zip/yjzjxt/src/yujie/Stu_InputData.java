/*    */ package yujie;
/*    */ 
/*    */ public class Stu_InputData
/*    */ {
/*    */   private String stu_ID;
/*    */   private String stu_Name;
/*    */   private String stu_Classes;
/*    */   private String stu_Courses;
/*    */   private String order;
/*    */   private String teacher;
/*    */   private String stu_Content;
/*    */ 
/*    */   public String getStu_ID()
/*    */   {
/* 19 */     return this.stu_ID;
/*    */   }
/*    */   public void setStu_ID(String sid) {
/* 22 */     this.stu_ID = sid;
/*    */   }
/*    */   public String getStu_Name() {
/* 25 */     return this.stu_Name;
/*    */   }
/*    */ 
/*    */   public void setStu_Name(String sname) {
/* 29 */     this.stu_Name = sname;
/*    */   }
/*    */ 
/*    */   public String getStu_Classes()
/*    */   {
/* 34 */     return this.stu_Classes;
/*    */   }
/*    */ 
/*    */   public void setStu_Classes(String sclasses) {
/* 38 */     this.stu_Classes = sclasses;
/*    */   }
/*    */ 
/*    */   public String getOrder() {
/* 42 */     return this.order;
/*    */   }
/*    */   public void setOrder(String or) {
/* 45 */     this.order = or;
/*    */   }
/*    */   public void setTeacher(String tea) {
/* 48 */     this.teacher = tea;
/*    */   }
/*    */ 
/*    */   public String getTeacher() {
/* 52 */     return this.teacher;
/*    */   }
/*    */ 
/*    */   public void setStu_Courses(String Courses) {
/* 56 */     this.stu_Courses = Courses;
/*    */   }
/*    */ 
/*    */   public String getStu_Courses() {
/* 60 */     return this.stu_Courses;
/*    */   }
/*    */ 
/*    */   public String getStu_Content() {
/* 64 */     return this.stu_Content;
/*    */   }
/*    */ 
/*    */   public void setStu_Content(String scontent) {
/* 68 */     this.stu_Content = scontent;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     yujie.Stu_InputData
 * JD-Core Version:    0.6.1
 */