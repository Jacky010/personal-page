/*    */ package yujie;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class DateTime
/*    */ {
/*    */   public String getDatetime()
/*    */   {
/*  9 */     Calendar calCurrent = Calendar.getInstance();
/*    */ 
/* 11 */     int intDay = calCurrent.get(5);
/* 12 */     int intMonth = calCurrent.get(2) + 1;
/* 13 */     int intYear = calCurrent.get(1);
/* 14 */     int intHour = calCurrent.get(11);
/* 15 */     int intMinute = calCurrent.get(12);
/* 16 */     int intSec = calCurrent.get(13);
/*    */ 
/* 18 */     return intYear + "-" + intMonth + "-" + intDay + " " + intHour + ":" + intMinute + ":" + intSec;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     yujie.DateTime
 * JD-Core Version:    0.6.1
 */