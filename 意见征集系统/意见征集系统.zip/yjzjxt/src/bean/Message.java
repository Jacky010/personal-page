/*    */ package bean;
/*    */ 
/*    */ public class Message
/*    */ {
/*    */   private String id;
/*    */   private String position;
/*    */   private String name;
/*    */   private String sex;
/*    */   private String email;
/*    */   private String Content;
/*    */   private String gbdate;
/*    */   private String redate;
/*    */   private String recontent;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 15 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 18 */     this.id = id;
/*    */   }
/*    */   public String getPosition() {
/* 21 */     return this.position;
/*    */   }
/*    */   public void setPosition(String position) {
/* 24 */     this.position = position;
/*    */   }
/*    */   public String getName() {
/* 27 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 30 */     this.name = name;
/*    */   }
/*    */   public String getSex() {
/* 33 */     return this.sex;
/*    */   }
/*    */   public void setSex(String sex) {
/* 36 */     this.sex = sex;
/*    */   }
/*    */   public String getEmail() {
/* 39 */     return this.email;
/*    */   }
/*    */   public void setEmail(String email) {
/* 42 */     this.email = email;
/*    */   }
/*    */   public String getContent() {
/* 45 */     return this.Content;
/*    */   }
/*    */   public void setContent(String content) {
/* 48 */     this.Content = content;
/*    */   }
/*    */   public String getGbdate() {
/* 51 */     return this.gbdate;
/*    */   }
/*    */   public void setGbdate(String gbdate) {
/* 54 */     this.gbdate = gbdate;
/*    */   }
/*    */   public String getRedate() {
/* 57 */     return this.redate;
/*    */   }
/*    */   public void setRedate(String redate) {
/* 60 */     this.redate = redate;
/*    */   }
/*    */   public String getRecontent() {
/* 63 */     return this.recontent;
/*    */   }
/*    */   public void setRecontent(String recontent) {
/* 66 */     this.recontent = recontent;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     bean.Message
 * JD-Core Version:    0.6.1
 */