// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PageHelp.java

package bean;

import java.util.List;

public class PageHelp
{

    public PageHelp()
    {
        pagebar = "";
    }

    public int getCurrentpage()
    {
        return currentpage;
    }

    public void setCurrentpage(int currentpage)
    {
        currentpage = currentpage;
    }

    public int getNextpage()
    {
        if(pagecount > currentpage)
            nextpage = currentpage + 1;
        else
            nextpage = currentpage;
        return nextpage;
    }

    public void setNextpage(int nextpage)
    {
        nextpage = nextpage;
    }

    public int getPriviouspage()
    {
        if(currentpage > 1)
            priviouspage = currentpage - 1;
        else
            priviouspage = currentpage;
        return priviouspage;
    }

    public void setPriviouspage(int priviouspage)
    {
        priviouspage = priviouspage;
    }

    public int getPagecount()
    {
        if(recordcount % pagesize == 0)
            pagecount = recordcount / pagesize;
        else
            pagecount = recordcount / pagesize + 1;
        return pagecount;
    }

    public void setPagecount(int pagecount)
    {
        pagecount = pagecount;
    }

    public int getRecordcount()
    {
        return recordcount;
    }

    public void setRecordcount(int recordcount)
    {
        recordcount = recordcount;
    }

    public int getPagesize()
    {
        return pagesize;
    }

    public void setPagesize(int pagesize)
    {
        pagesize = pagesize;
    }

    public String getSqlstr()
    {
        return sqlstr;
    }

    public void setSqlstr(String sqlstr)
    {
        this.sqlstr = sqlstr;
    }

    public List getObjectlist()
    {
        return objectlist;
    }

    public void setObjectlist(List objectlist)
    {
        this.objectlist = objectlist;
    }

    public String getPagebar()
    {
        return pagebar;
    }

    public void setPagebar(String url)
    {
        String strResult = "";
        if(currentpage <= 1)
        {
            strResult = (new StringBuilder(String.valueOf(strResult))).append(strResult).append("[\u9996 \u9875] [\u4E0A \u9875] ").toString();
        } else
        {
            strResult = (new StringBuilder(String.valueOf(strResult))).append("<a href=").append(url).append("&currentPage=1>[\u9996 \u9875]</a> ").toString();
            strResult = (new StringBuilder(String.valueOf(strResult))).append("<a href=").append(url).append("&currentPage=").append(currentpage - 1).append(">[\u4E0A \u9875]<a>").toString();
        }
        if(currentpage >= pagecount)
        {
            strResult = (new StringBuilder(String.valueOf(strResult))).append("[\u4E0B \u9875] [\u5C3E \u9875]").toString();
        } else
        {
            strResult = (new StringBuilder(String.valueOf(strResult))).append("<a href=").append(url).append("&currentPage=").append(currentpage + 1).append(">[\u4E0B \u9875]<a>").toString();
            strResult = (new StringBuilder(String.valueOf(strResult))).append("<a href=").append(url).append("&currentPage=").append(pagecount).append("> [\u5C3E \u9875]<a> ").toString();
        }
        String strSelect = "<form method='post' id='f1' name='f1'>\n<select name='page' onchange='return selPage();'>\n";
        for(int i = 1; i <= pagecount; i++)
            if(currentpage == i)
                strSelect = (new StringBuilder(String.valueOf(strSelect))).append("<option value='").append(i).append("' selected=\"selected\">\u7B2C").append(i).append("\u9875</option>\n").toString();
            else
                strSelect = (new StringBuilder(String.valueOf(strSelect))).append("<option value='").append(i).append("'>\u7B2C").append(i).append("\u9875</option>").toString();

        strSelect = (new StringBuilder(String.valueOf(strSelect))).append("\n</select>\n</form>\n<script type='text/javascript'>function selPage(){document.f1.action = '").append(url).append("&currentPage='+document.f1.page.value; document.f1.submit(); return true;}</script>").toString();
        strResult = (new StringBuilder("\u7B2C")).append(currentpage).append("/").append(pagecount).append("\u9875,\u6BCF\u9875").append(pagesize).append("\u6761  ").append(strResult).append("   ").append(strSelect).toString();
        if(pagecount > 1)
            pagebar = strResult;
        if(recordcount < 1)
            pagebar = "\u6682\u65E0\u7559\u8A00";
    }

    private static int currentpage;
    private static int nextpage;
    private static int priviouspage;
    private static int pagecount;
    private static int recordcount;
    private static int pagesize;
    private String sqlstr;
    private List objectlist;
    private String pagebar;
}
