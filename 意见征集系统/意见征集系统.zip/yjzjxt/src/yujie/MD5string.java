/*    */ package yujie;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ public class MD5string
/*    */ {
/*    */   public String getmd5string(String csinput)
/*    */   {
/* 11 */     String csreturn = null;
/*    */     try
/*    */     {
/* 15 */       byte[] b = csinput.getBytes("iso-8859-1");
/* 16 */       MessageDigest md = MessageDigest.getInstance("MD5");
/* 17 */       md.update(b);
/* 18 */       byte[] b2 = md.digest();
/*    */ 
/* 20 */       StringBuffer buf = new StringBuffer(b2.length * 2);
/* 21 */       for (int nloopindex = 0; nloopindex < b2.length; nloopindex++)
/*    */       {
/* 23 */         if ((b2[nloopindex] & 0xFF) < 16)
/*    */         {
/* 25 */           buf.append("0");
/*    */         }
/* 27 */         buf.append(Long.toString(b2[nloopindex] & 0xFF, 16));
/*    */       }
/* 29 */       csreturn = new String(buf);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 33 */       e.printStackTrace();
/* 34 */       csreturn = null;
/*    */     }
/*    */ 
/* 37 */     return csreturn;
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     yujie.MD5string
 * JD-Core Version:    0.6.1
 */