// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoginServlet.java

package servlet;

import java.io.IOException;
import java.io.PrintStream;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import xmlmgr.LoginMgr;

public class LoginServlet extends HttpServlet
{

    public LoginServlet()
    {
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        System.out.println((new StringBuilder("action:")).append(action).toString());
        if(action.equals("login"))
        {
            String adminName = request.getParameter("adminName");
            String adminPass = request.getParameter("adminPass");
            LoginMgr lm = new LoginMgr();
            if(lm.isAdmin(adminName, adminPass))
            {
                request.getSession().setAttribute("adminName", adminName);
                request.getRequestDispatcher("gbook.jsp").forward(request, response);
            } else
            {
                request.setAttribute("toptips", "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF\uFF0C\u8BF7\u91CD\u65B0\u8F93\u5165\uFF01\uFF01");
                request.getRequestDispatcher("admin.jsp").forward(request, response);
            }
        } else
        if(action.equals("quit"))
        {
            request.getSession().invalidate();
            request.getRequestDispatcher("../Student/logout.jsp").forward(request, response);
        }
    }
}
