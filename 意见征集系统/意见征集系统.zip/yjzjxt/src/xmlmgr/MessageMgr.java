/*     */ package xmlmgr;
/*     */ 
/*     */ import bean.Message;
/*     */ import bean.PageHelp;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ public class MessageMgr
/*     */ {
/*  16 */   private String xmlPath = "";
/*     */ 
/*     */   public MessageMgr() {
/*  19 */     this.xmlPath = 
/*  20 */       getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
/*  21 */     this.xmlPath = 
/*  22 */       (this.xmlPath.substring(1, this.xmlPath.indexOf("WEB-INF1/classes")) + 
/*  22 */       "data/gbook.xml");
/*     */   }
/*     */ 
/*     */   public PageHelp getMessages(int pageSize, int currentPage)
/*     */   {
/*  27 */     int listSize = 0;
/*  28 */     List showlist = new ArrayList();
/*  29 */     PageHelp pageHelp = new PageHelp();
/*     */     try
/*     */     {
/*  33 */       DocumentBuilderFactory factory = 
/*  34 */         DocumentBuilderFactory.newInstance();
/*  35 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*  36 */       Document doc = builder.parse(this.xmlPath);
/*  37 */       doc.normalize();
/*  38 */       NodeList messages = doc.getElementsByTagName("message");
/*     */ 
/*  40 */       listSize = messages.getLength();
/*     */ 
/*  42 */       int i = listSize - 1 - (currentPage - 1) * pageSize;
/*     */       do {
/*  44 */         Element message = (Element)messages.item(i);
/*  45 */         Message mess = new Message();
/*     */ 
/*  47 */         mess.setId(
/*  48 */           message.getElementsByTagName("id").item(0).getFirstChild().getNodeValue());
/*  49 */         mess.setPosition(String.valueOf(i + 1));
/*  50 */         mess.setName(
/*  51 */           message.getElementsByTagName("name").item(0).getFirstChild().getNodeValue());
/*  52 */         mess.setSex(
/*  53 */           message.getElementsByTagName("sex").item(0).getFirstChild().getNodeValue());
/*  54 */         mess.setEmail(
/*  55 */           message.getElementsByTagName("email").item(0).getFirstChild().getNodeValue());
/*  56 */         mess.setContent(
/*  57 */           message.getElementsByTagName("content").item(0).getFirstChild().getNodeValue());
/*  58 */         mess.setGbdate(
/*  59 */           message.getElementsByTagName("gbdate").item(0).getFirstChild().getNodeValue());
/*     */ 
/*  61 */         if (message.getElementsByTagName("recontent").item(0)
/*  61 */           .getFirstChild().getNodeValue().equals("暂未回复"))
/*  62 */           mess.setRecontent("");
/*     */         else {
/*  64 */           mess.setRecontent(
/*  65 */             message.getElementsByTagName("recontent").item(0).getFirstChild().getNodeValue());
/*     */         }
/*  67 */         mess.setRedate(
/*  68 */           message.getElementsByTagName("redate").item(0).getFirstChild().getNodeValue());
/*     */ 
/*  70 */         showlist.add(mess);
/*     */ 
/*  43 */         i--;
/*     */ 
/*  42 */         if (i < 0) break; 
/*  43 */       }while (i > listSize - 1 - currentPage * pageSize);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  73 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  76 */     pageHelp.setCurrentpage(currentPage);
/*  77 */     pageHelp.setPagesize(pageSize);
/*  78 */     pageHelp.setRecordcount(listSize);
/*  79 */     pageHelp.getPagecount();
/*  80 */     pageHelp.setPagebar("messageServlet?action=list");
/*  81 */     pageHelp.setObjectlist(showlist);
/*     */ 
/*  83 */     return pageHelp;
/*     */   }
/*     */ 
/*     */   public int addMessage(Message ms)
/*     */   {
/*  88 */     int addresult = 0;
/*     */     try {
/*  90 */       DocumentBuilderFactory factory = 
/*  91 */         DocumentBuilderFactory.newInstance();
/*  92 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*  93 */       Document doc = builder.parse(this.xmlPath);
/*  94 */       doc.normalize();
/*     */ 
/*  97 */       Element message = doc.createElement("message");
/*     */ 
/* 100 */       Element id = doc.createElement("id");
/* 101 */       Text textId = doc.createTextNode(ms.getId());
/* 102 */       id.appendChild(textId);
/* 103 */       message.appendChild(id);
/*     */ 
/* 105 */       Element name = doc.createElement("name");
/* 106 */       Text textName = doc.createTextNode(ms.getName());
/* 107 */       name.appendChild(textName);
/* 108 */       message.appendChild(name);
/*     */ 
/* 110 */       Element sex = doc.createElement("sex");
/* 111 */       Text textSex = doc.createTextNode(ms.getSex());
/* 112 */       sex.appendChild(textSex);
/* 113 */       message.appendChild(sex);
/*     */ 
/* 115 */       Element email = doc.createElement("email");
/* 116 */       Text textEmail = doc.createTextNode(ms.getEmail());
/* 117 */       email.appendChild(textEmail);
/* 118 */       message.appendChild(email);
/*     */ 
/* 120 */       Element content = doc.createElement("content");
/* 121 */       Text textContent = doc.createTextNode(ms.getContent());
/* 122 */       content.appendChild(textContent);
/* 123 */       message.appendChild(content);
/*     */ 
/* 125 */       Element gbdate = doc.createElement("gbdate");
/* 126 */       Text textGbdate = doc.createTextNode(ms.getGbdate());
/* 127 */       gbdate.appendChild(textGbdate);
/* 128 */       message.appendChild(gbdate);
/*     */ 
/* 130 */       Element recontent = doc.createElement("recontent");
/* 131 */       Text textRecontent = doc.createTextNode(ms.getRecontent());
/* 132 */       recontent.appendChild(textRecontent);
/* 133 */       message.appendChild(recontent);
/*     */ 
/* 135 */       Element redate = doc.createElement("redate");
/* 136 */       Text textRedate = doc.createTextNode(ms.getRedate());
/* 137 */       redate.appendChild(textRedate);
/* 138 */       message.appendChild(redate);
/*     */ 
/* 140 */       doc.getDocumentElement().appendChild(message);
/* 141 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 142 */       Transformer transformer = tFactory.newTransformer();
/* 143 */       DOMSource source = new DOMSource(doc);
/* 144 */       StreamResult result = new StreamResult(new File(this.xmlPath));
/* 145 */       transformer.transform(source, result);
/*     */ 
/* 147 */       addresult = 1;
/*     */     } catch (Exception e) {
/* 149 */       e.printStackTrace();
/*     */     }
/* 151 */     return addresult;
/*     */   }
/*     */ 
/*     */   public int delMessage(String id) {
/* 155 */     int delResult = 0;
/*     */     try {
/* 157 */       DocumentBuilderFactory factory = 
/* 158 */         DocumentBuilderFactory.newInstance();
/* 159 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 160 */       Document doc = builder.parse(this.xmlPath);
/* 161 */       doc.normalize();
/*     */ 
/* 166 */       NodeList list = doc.getElementsByTagName("message");
/*     */ 
/* 168 */       for (int i = 0; i < list.getLength(); i++) {
/* 169 */         Element el = (Element)list.item(i);
/*     */ 
/* 171 */         if (el.getElementsByTagName("id").item(0).getFirstChild()
/* 171 */           .getNodeValue().equals(id)) {
/* 172 */           Node del = el;
/* 173 */           el.getParentNode().removeChild(del);
/* 174 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 178 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 179 */       Transformer transformer = tFactory.newTransformer();
/* 180 */       DOMSource source = new DOMSource(doc);
/* 181 */       StreamResult result = new StreamResult(new File(this.xmlPath));
/* 182 */       transformer.transform(source, result);
/*     */ 
/* 184 */       delResult = 1;
/*     */     } catch (Exception ex) {
/* 186 */       ex.printStackTrace();
/*     */     }
/* 188 */     return delResult;
/*     */   }
/*     */ 
/*     */   public int updateMessage(String id, String recontent) {
/* 192 */     int updateResult = 0;
/*     */     try {
/* 194 */       DocumentBuilderFactory factory = 
/* 195 */         DocumentBuilderFactory.newInstance();
/* 196 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 197 */       Document doc = builder.parse(this.xmlPath);
/* 198 */       doc.normalize();
/*     */ 
/* 202 */       NodeList list = doc.getElementsByTagName("message");
/*     */ 
/* 204 */       for (int i = 0; i < list.getLength(); i++) {
/* 205 */         Element el = (Element)list.item(i);
/*     */ 
/* 207 */         if (el.getElementsByTagName("id").item(0).getFirstChild()
/* 207 */           .getNodeValue().equals(id))
/*     */         {
/* 209 */           Date now = new Date();
/* 210 */           SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 211 */           String redate = formatter.format(now);
/*     */ 
/* 213 */           el.getElementsByTagName("recontent").item(0).getFirstChild().setNodeValue(recontent);
/* 214 */           el.getElementsByTagName("redate").item(0).getFirstChild().setNodeValue(redate);
/*     */ 
/* 216 */           updateResult = 1;
/*     */ 
/* 218 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 222 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 223 */       Transformer transformer = tFactory.newTransformer();
/* 224 */       DOMSource source = new DOMSource(doc);
/* 225 */       StreamResult result = new StreamResult(new File(this.xmlPath));
/* 226 */       transformer.transform(source, result);
/*     */ 
/* 228 */       updateResult = 1;
/*     */     } catch (Exception ex) {
/* 230 */       ex.printStackTrace();
/*     */     }
/* 232 */     return updateResult;
/*     */   }
/*     */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     xmlmgr.MessageMgr
 * JD-Core Version:    0.6.1
 */