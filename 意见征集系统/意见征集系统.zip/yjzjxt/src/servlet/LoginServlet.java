/*    */ package servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import xmlmgr.LoginMgr;
/*    */ 
/*    */ public class LoginServlet extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 17 */     doPost(request, response);
/*    */   }
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 23 */     request.setCharacterEncoding("UTF-8");
/* 24 */     response.setCharacterEncoding("UTF-8");
/*    */ 
/* 26 */     String action = request.getParameter("action");
/* 27 */     System.out.println("action:" + action);
/*    */ 
/* 29 */     if (action.equals("login")) {
/* 30 */       String adminName = request.getParameter("adminName");
/* 31 */       String adminPass = request.getParameter("adminPass");
/*    */ 
/* 34 */       LoginMgr lm = new LoginMgr();
/* 35 */       if (lm.isAdmin(adminName, adminPass)) {
/* 36 */         request.getSession().setAttribute("adminName", adminName);
/* 37 */         request.getRequestDispatcher("gbook.jsp").forward(request, 
/* 38 */           response);
/*    */       } else {
/* 40 */         request.setAttribute("toptips", "用户名或密码错误，请重新输入！！");
/* 41 */         request.getRequestDispatcher("admin.jsp").forward(request, 
/* 42 */           response);
/*    */       }
/* 44 */     } else if (action.equals("quit")) {
/* 45 */       request.getSession().invalidate();
/* 46 */       request.getRequestDispatcher("gbook.jsp")
/* 47 */         .forward(request, response);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\caiyuan\yjzjxt\WEB-INF\classes\
 * Qualified Name:     servlet.LoginServlet
 * JD-Core Version:    0.6.1
 */